export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>GreenLine Energy</h1>
      <p>Welcome to our new site — deployed on Vercel 🚀</p>
    </div>
  );
}
